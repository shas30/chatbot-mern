
In this project My new leaning was to learn @mui/material ui which helped me creating beautidul interfaces for my application.