import React from "react";

const NotFound = () => {
  return <div>We are not able to locate page you are searching for</div>;
};

export default NotFound;
