
# MERN Stack AI Chatbot
Hey This is Kartik Kumar I followed a youtube tutorial to enhance my learning in Full Stack Development.
Through this project I was able to understand how external APis are used to interact with interface of any application. 

This is an AI Chatbot application, inspired by ChatGPT, by using MERN Stack and OpenAI

It's a customized chatbot where each message of the user is stored in DB and can be retrieved and deleted.

It's a completely secure application using:
->JWT Tokens 
->HTTP-Only Cookies 
->Signed Cookies 
->Password Encryption 
->Middleware Chains


